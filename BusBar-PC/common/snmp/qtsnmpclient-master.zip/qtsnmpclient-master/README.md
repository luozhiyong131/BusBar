# qtsnmpclient
The Qt based library for communication with SNMP agent (like your Network Router).
