/*
 * devDataSent.h
 *
 *  Created on: 2016年7月29日
 *      Author: Lzy
 */

#ifndef DEVDATA_DEVDATASENT_H_
#define DEVDATA_DEVDATASENT_H_

#include "devDataType.h"

void sent_test(void);

#endif /* DEVDATA_DEVDATASENT_H_ */
